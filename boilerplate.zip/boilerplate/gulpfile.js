'use strict';

var gulp = require('gulp');
var sass = require('gulp-sass');
var htmlmin = require('gulp-htmlmin');
var size = require('gulp-size');
var imagemin = require('gulp-imagemin');
var usemin = require('gulp-usemin');
var minifyCss = require('gulp-minify-css');
var rev = require('gulp-rev');
var uglify = require('gulp-uglify');
var clean = require('gulp-clean');
var gulpSequence = require('gulp-sequence');
var minifyHtml = require('gulp-minify-html');
var uncss = require('gulp-uncss');
var nano = require('gulp-cssnano');


//Sass compile only once
gulp.task('sass', function () {
    gulp.src('./assets/scss/**/*.scss')
            .pipe(sass().on('error', sass.logError))
            .pipe(gulp.dest('./assets/css'));
});




gulp.task('uncss', function () {
    gulp.src('./assets/scss/**/*.scss')
            .pipe(sass())
            .pipe(uncss({
                html: ['./index.html', './pages/*.html']
            }))
            .pipe(gulp.dest('./assets/css'));
});


//Sass compile on save
gulp.task('sass:watch', function () {
    gulp.watch('./assets/scss/**/*.scss', ['sass']);
});

gulp.task('clean', function () {
    return gulp.src('./dist', {read: false})
            .pipe(clean());
});

//Minify Html
gulp.task('html', function () {
    return gulp.src(['./**/*.html', '!node_modules/**', '!dist/**', '!./index.html'])
            .pipe(htmlmin({collapseWhitespace: true}))
            .pipe(gulp.dest('dist'))
            .pipe(size({title: 'html'}));
});


//Optimize images
gulp.task('imagemin', function () {
    return gulp.src('assets/img/*')
            .pipe(imagemin())
            .pipe(gulp.dest('dist/assets/img'));
});

// Copy Fonts
gulp.task('fonts', function () {
    return gulp.src(['assets/fonts/*', 'bower_components/font-awesome/fonts/fontawesome-webfont.*'])
            .pipe(gulp.dest('dist/assets/fonts/'));
});


//Minify Css
gulp.task('css', function () {
    return gulp.src('./*.html')
            .pipe(usemin({
                css: [minifyCss(), rev()],
                html: [minifyHtml({empty: true})],
                js: [uglify(), rev()],
                inlinejs: [uglify()],
                inlinecss: [minifyCss(), 'concat']
            }))
            
            .pipe(gulp.dest('dist/'));
});

//Production of code
gulp.task('prod', gulpSequence('clean', 'css', 'html', 'imagemin', 'fonts'));

//Default task
gulp.task('default', ['sass:watch']);
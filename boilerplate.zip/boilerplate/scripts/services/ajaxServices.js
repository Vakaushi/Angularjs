angular.module('ajaxServices', [])

    // super simple service
    // each function returns a promise object 
    .factory('Ajax', ['$http', function ($http) {
        return {
            registerUser: function () {
                return $http.get('admin/webservice.php?operation=startapp');
            },
        };
    }]);
// create the module and name it angularApp
var BoilerPlate = angular.module('BoilerPlate', ['ngRoute', 'ngMessages', 'ajaxServices'])

    // configure our routes
    .config(['$routeProvider', function ($routeProvider) {
        $routeProvider

            // route for the home page
            .when('/pageone/', {
                templateUrl: 'pages/pageOne.html',
                controller: 'pageOneController'
            })

            // route for the about page
            .when('/pagetwo/', {
                templateUrl: 'pages/pageTwo.html',
                controller: 'pageSecondController'
            })
            //
            .otherwise({ redirectTo: '/pageone' });
    }])

    // create the controller and inject Angular's $scope
    .controller('pageOneController', ['$scope', function ($scope) {
        $scope.title = "Page one";
		$scope.signupForm=function(){
			alert("alert");
		}
    }])

    // create the controller and inject Angular's $scope
    .controller('pageSecondController', ['$scope', function ($scope) {
        $scope.title = "Page two";
    }])
	
	 .directive('onlyDigits', function () {
    return {
      require: 'ngModel',
      restrict: 'A',
      link: function (scope, element, attr, ctrl) {
        function inputValue(val) {
          if (val) {
            var digits = val.replace(/[^0-9]/g, '');

            if (digits !== val) {
              ctrl.$setViewValue(digits);
              ctrl.$render();
            }
            return parseInt(digits,10);
          }
          return undefined;
        }            
        ctrl.$parsers.push(inputValue);
      }
    };
});

